import { InjectionToken } from '@angular/core';


export const APP_CONFIG = new InjectionToken<any>(
  'Application config'
);