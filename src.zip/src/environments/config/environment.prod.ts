export const environment = {
  app_name: 'apa-front-v2',
  environment: 'dev',
  mocksEnabled: true,
  apiUrl: 'https://sl-dev-backend-7ab91220ba93.herokuapp.com'
};