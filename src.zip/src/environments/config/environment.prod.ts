
export const environment = {
  app_name: 'apa-front-v2',
  environment: 'dev',
  mocksEnabled: false
};