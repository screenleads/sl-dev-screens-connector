export const environment = {
    app_name: 'apa-front-v2',
    environment: 'dev',
    mocksEnabled: true,
    apiUrl: 'https://sl-dev-backend-pre-7ca702711a78.herokuapp.com/'
};